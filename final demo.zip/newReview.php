<?php
$con = mysqli_connect
("localhost","your_localhost_database_user",
"your_localhost_database_password","VirtualTeaClub")

$brand = $_POST['brand'];
$type = $_POST['type'];
$comments = $_POST['comments'];
$sql = "INSTERT INTO 'tbl_reviews' ('user','bfldBrand', 'fldType', 'fldComments') VALUES('guest-user', '$brand', '$type', '$comments')";

$rs = mysqli_query($con, $sql);
if($rs)
{
	echo "Review Posted"
}
?>